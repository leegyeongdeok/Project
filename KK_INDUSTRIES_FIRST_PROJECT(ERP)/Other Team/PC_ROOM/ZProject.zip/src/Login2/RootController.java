package Login2;

import javafx.fxml.Initializable;

public class RootController implements Initializable{
	@FXML private
	@FXML private
	@FXML private
	@FXML private

}
