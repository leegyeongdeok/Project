package main;


import java.awt.Color;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PCMain extends Application {
	public static void main(String[] args) {
		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/View/AdminView.fxml"));
		Parent root = fxmlLoader.load();
		Scene scene = new Scene(root);
		
		 //LoginController loginController = fxmlLoader.getController();
		// loginController.setPrimaryStage(primaryStage);
	
		primaryStage.setScene(scene);
		primaryStage.setTitle("돈관리좀 해라 가계부");
		primaryStage.setResizable(false);
		primaryStage.show();
		
	}

}