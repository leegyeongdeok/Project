package model;

public class Imformation {
	private String custno;
	private String Name;
	private String Jumin;
	private String Tel;	
	private String Height;
	private String Weight;
	private String Gender;
	private String Pay;
	private String txtid;
	private String txtPW;
	private String Career;
	
	public Imformation(String custno, String Name, String Jumin, String Tel, String Height, String Weight, String Gender, String Pay, String txtid, String txtPW, String Career) {
		super();
		this.custno = custno;
		this.Name = Name;
		this.Jumin = Jumin;
		this.Tel = Tel;
		this.Height = Height;
		this.Weight = Weight;
		this.Gender = Gender;
		this.Pay = Pay;
		this.txtid = txtid;
		this.txtPW = txtPW;
		this.Career = Career;
	}

	public Imformation(String txtid, String txtPW) {
		super();
		this.txtid = txtid;
		this.txtPW = txtPW;
	}

	public String getCustno() {
		return custno;
	}

	public void setCustno(String custno) {
		this.custno = custno;
	}
	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}
	public String getJumin() {
		return Jumin;
	}
	
	public void setJumin(String Jumin) {
		this.Jumin = Jumin;
	}
	public String getTel() {
		return Tel;
	}
	
	public void setTel(String Tel) {
		this.Tel = Tel;
	}

	public String getHeight() {
		return Height;
	}
	
	public void setHeight(String Height) {
		this.Height = Height;
	}
	
	public String getWeight() {
		return Weight;
	}
	
	public void setWeight(String Weight) {
		this.Weight = Weight;
	}
	public String getTxtid() {
		return txtid;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String Gender) {
		this.Gender = Gender;
	}

	public String getPay() {
		return Pay;
	}

	public void setPay(String Pay) {
		this.Pay = Pay;
	}

	
	public void setTxtid(String txtid) {
		this.txtid = txtid;
	}

	public String getTxtPW() {
		return txtPW;
	}

	public void setTxtPW(String txtPW) {
		this.txtPW = txtPW;
	}
	public String getCareer() {
		return Career;
	}
	
	public void setCareer(String Career) {
		this.Career = Career;
	}
}