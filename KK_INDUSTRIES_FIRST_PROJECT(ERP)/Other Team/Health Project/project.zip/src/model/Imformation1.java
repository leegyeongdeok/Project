package model;

public class Imformation1 {
	private String trainno;
	private String Name;
	private String Jumin;
	private String Height;
	private String Weight;
	private String Career;
	private String Tel;	
	private String Gender;
	private String custno;
	private String txtid;
	private String txtPW;
	
	public Imformation1(String trainno, String Name, String Jumin, String Height, String Weight, String Career, String Gender, String Tel, String custno, String txtid, String txtPW) {
		super();
		this.trainno = trainno;
		this.Name = Name;
		this.Jumin = Jumin;
		this.Height = Height;
		this.Weight = Weight;
		this.Career = Career;
		this.Gender = Gender;
		this.Tel = Tel;
		this.custno = custno;
		this.txtid = txtid;
		this.txtPW = txtPW;
	}

	public Imformation1(String txtid, String txtPW) {
		super();
		this.txtid = txtid;
		this.txtPW = txtPW;
	}

	public String getTrainno() {
		return trainno;
	}

	public void setTrainno(String trainno) {
		this.trainno = trainno;
	}
	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}
	public String getJumin() {
		return Jumin;
	}
	
	public void setJumin(String Jumin) {
		this.Jumin = Jumin;
	}
	public String getHeight() {
		return Height;
	}
	
	public void setHeight(String Height) {
		this.Height = Height;
	}
	
	public String getWeight() {
		return Weight;
	}
	
	public void setWeight(String Weight) {
		this.Weight = Weight;
	}
	public String getCareer() {
		return Career;
	}
	
	public void setCareer(String Career) {
		this.Career = Career;
	}
	public String getGender() {
		return Gender;
	}
	
	public void setGender(String Gender) {
		this.Gender = Gender;
	}
	public String getTel() {
		return Tel;
	}
	
	public void setTel(String Tel) {
		this.Tel = Tel;
	}
	public String getCustno() {
		return custno;
	}
	
	public void setCustno(String custno) {
		this.custno = custno;
	}

	public String getTxtid() {
		return txtid;
	}
	
	public void setTxtid(String txtid) {
		this.txtid = txtid;
	}

	public String getTxtPW() {
		return txtPW;
	}

	public void setTxtPW(String txtPW) {
		this.txtPW = txtPW;
	}
}