package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import controller.DBfile;
import controller.function;
import model.Imformation;

public class listDAO {
	function fun = new function();

	public void deleteUse(String loginID) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int queryResultNumber = 0;

		try {
			con = DBfile.getConnection();
			String dml = "delete from customer where c_id = ?";
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, loginID);

			// 3-2 명령을 하달한다
			queryResultNumber = pstmt.executeUpdate(); // query -> select 명령 // update -> delete , insert, update명령

		} catch (SQLException e) {
			System.out.println("error = [" + e + "]");
		} catch (Exception e1) {
			System.out.println("error = [" + e1 + "]");
		} finally {

			try {
				if (pstmt != null) {
					pstmt.close();
				}

				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			}
		}
		return;
	}

	public ArrayList<Imformation> editImformationView(Imformation memberImformation,
			Imformation tableSelectImformation) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<Imformation> list = new ArrayList<Imformation>();

		try {
			con = DBfile.getConnection();
			String dml = "select * from customer where c_id = ?";
			pstmt = con.prepareStatement(dml);

			pstmt.setString(1, tableSelectImformation.getTxtid());

			ResultSet queryResultSet = pstmt.executeQuery();

			while (queryResultSet.next()) { // 대기하고 있는 레코드 값이 있는지 확인하는것
				String custno = String.valueOf(queryResultSet.getString(1));
				String Name  = String.valueOf(queryResultSet.getString(2));
				String Jumin = String.valueOf(queryResultSet.getString(3));
				String Tel = String.valueOf(queryResultSet.getString(4));
				String Height = String.valueOf(queryResultSet.getString(5));
				String Weight= String.valueOf(queryResultSet.getString(6));
				String Gender = String.valueOf(queryResultSet.getString(7));
				String Pay = String.valueOf(queryResultSet.getString(8));
				String txtid = String.valueOf(queryResultSet.getString(9));
				String txtPW = String.valueOf(queryResultSet.getString(10));
				String Career = String.valueOf(queryResultSet.getString(11));
				Imformation memberImformation2 = new Imformation(custno, Name, Jumin, Tel, Height, Weight, Gender, Pay, txtid, txtPW, Career);

				list.add(memberImformation2);
			}
		} catch (SQLException e) {
			System.out.println("error = [" + e + "]");
		} catch (Exception e1) {
			System.out.println("error = [" + e1 + "]");
		} finally {

			try {
				if (pstmt != null) {
					pstmt.close();
				}

				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			}
		} // end to finally
		return list;
	}

	public int editImformation(Imformation memberImformation, Imformation tableSelectImformation) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int queryResultNumber = 0;

		try {
			con = DBfile.getConnection();
			String dml = "update customer set c_name = ? , c_id = ?, c_pw = ?, c_jumin = ?, c_tel = ?, c_Height = ?, c_Weight = ?, c_Career = ? where c_id = ?";
			pstmt = con.prepareStatement(dml);

			pstmt.setString(1, memberImformation.getName());
			pstmt.setString(2, memberImformation.getTxtid());
			pstmt.setString(3, memberImformation.getTxtPW());
			pstmt.setString(4, memberImformation.getJumin());
			pstmt.setString(5, memberImformation.getTel());
			pstmt.setString(6, memberImformation.getHeight());
			pstmt.setString(7, memberImformation.getWeight());
			pstmt.setString(8, memberImformation.getCareer());
			pstmt.setString(9, tableSelectImformation.getTxtid());

			queryResultNumber = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("error = [" + e + "]");
		} catch (Exception e1) {
			System.out.println("error = [" + e1 + "]");
		} finally {

			try {
				if (pstmt != null) {
					pstmt.close();
				}

				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			}
		} // end to finally
		return queryResultNumber;
	}

	// db에서 불러오기
	public ArrayList<Imformation> memberAllLoad() {

		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<Imformation> list = new ArrayList<Imformation>();
		int queryResultNumber = 0;

		try {
			con = DBfile.getConnection();
			String dml = "select * from customer";
			pstmt = con.prepareStatement(dml);

			// 3-2 명령을 하달한다 결과값을 받는다 (Result (==ArrayList 같다고 생각해도 무방하다))
			ResultSet queryResultSet = pstmt.executeQuery(); // query -> select 명령 // update -> delete , insert,
																// update명령
			while (queryResultSet.next()) { // 대기하고 있는 레코드 값이 있는지 확인하는것
				
				String custno = String.valueOf(queryResultSet.getString(1));
				String Name  = String.valueOf(queryResultSet.getString(2));
				String Jumin = String.valueOf(queryResultSet.getString(3));
				String Tel = String.valueOf(queryResultSet.getString(4));
				String Height = String.valueOf(queryResultSet.getString(5));
				String Weight= String.valueOf(queryResultSet.getString(6));
				String Gender = String.valueOf(queryResultSet.getString(7));
				String Pay = String.valueOf(queryResultSet.getString(8));
				String txtid = String.valueOf(queryResultSet.getString(9));
				String txtPW = String.valueOf(queryResultSet.getString(10));
				String Career = String.valueOf(queryResultSet.getString(11));
				Imformation memberImformation = new Imformation(custno, Name, Jumin, Tel, Height, Weight, Gender, Pay, txtid, txtPW, Career);
				list.add(memberImformation);
			}
		} catch (SQLException e1) {
			System.out.println("error = [" + e1 + "]");
		} catch (Exception e) {
			System.out.println("error = [" + e + "]");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			} // end of try
		}
		return list;
	}

	public ArrayList<Imformation> memberNameLoad(String txtName) {

		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<Imformation> list = new ArrayList<Imformation>();
		int queryResultNumber = 0;

		try {
			con = DBfile.getConnection();
			String dml = "select * from customer where c_name = ?";
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, txtName);

			// 3-2 명령을 하달한다 결과값을 받는다 (Result (==ArrayList 같다고 생각해도 무방하다))
			ResultSet queryResultSet = pstmt.executeQuery(); // query -> select 명령 // update -> delete , insert,
			while (queryResultSet.next()) { // 대기하고 있는 레코드 값이 있는지 확인하는것
				String custno = String.valueOf(queryResultSet.getString(1));
				String Name  = String.valueOf(queryResultSet.getString(2));
				String Jumin = String.valueOf(queryResultSet.getString(3));
				String Tel = String.valueOf(queryResultSet.getString(4));
				String Height = String.valueOf(queryResultSet.getString(5));
				String Weight= String.valueOf(queryResultSet.getString(6));
				String Gender = String.valueOf(queryResultSet.getString(7));
				String Pay = String.valueOf(queryResultSet.getString(8));
				String txtid = String.valueOf(queryResultSet.getString(9));
				String txtPW = String.valueOf(queryResultSet.getString(10));
				String Career = String.valueOf(queryResultSet.getString(11));
				Imformation memberImformation = new Imformation(custno, Name, Jumin, Tel, Height, Weight, Gender, Pay, txtid, txtPW, Career);


				list.add(memberImformation);
			}
		} catch (SQLException e1) {
			System.out.println("error = [" + e1 + "]");
		} catch (Exception e) {
			System.out.println("error = [" + e + "]");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			} // end of try
		}
		return list;
	}
}
