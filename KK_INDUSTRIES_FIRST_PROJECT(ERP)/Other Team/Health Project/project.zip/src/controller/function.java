package controller;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class function {
	 public void alertDisplay(int number, String title, String header, String content) {
	      Alert alert = null;               //경고창 클래스 / dialog창 만드는 건(서브 ui를 따로 만든다는 건) fxml 파일 또 만들고 해야 하니 그러지 말고 그냥 코드로 해결
	      switch(number) {
	      case 1: alert = new Alert(AlertType.ERROR); break;
	      case 2: alert = new Alert(AlertType.WARNING); break;         //경고창을 선택/ Alert 객체 주소를 저장 / AlertType 5가지
	      default : break;
	      }
	      alert.setTitle(title);
	      alert.setHeaderText(header);
	      alert.setContentText(content);
	      alert.setResizable(false);
	      alert.showAndWait();
	      return;
	      
	   }
}
