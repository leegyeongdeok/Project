package controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.jar.Attributes.Name;
import java.util.regex.Pattern;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Imformation;
import model.Imformation1;

public class LoginController implements Initializable {
	@FXML
	private Button btnlogin;
	@FXML
	private Button btncustomersignup;
	@FXML
	private Button btntrainersignup;
	@FXML
	private TextField loginid;
	@FXML
	private PasswordField loginpw;
	@FXML
	private TextField jumin1;
	@FXML
	private PasswordField jumin2;
	@FXML
	private TextField tel1;
	@FXML
	private TextField tel2;
	@FXML
	private TextField tel3;
	@FXML
	RadioButton men;
	@FXML
	RadioButton girl;

	private Stage primaryStage;
	private boolean idOverlap;
	private boolean passwordOverlap;
	private function fun = new function();
	private CustomerLoginDAO lDAO = new CustomerLoginDAO();
	private MasterLoginDAO mDAO = new MasterLoginDAO();

	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnlogin.setOnAction((e) -> {
			handlerLogin(e);
		});
		btncustomersignup.setOnAction(e -> {
			handlercustomerSignup(e);
		});
		btntrainersignup.setOnAction(e -> {
			handlertrainSignup(e);
		});
}
	private void handlerLogin(ActionEvent e) {
		int resultNumber2 = 0;
		int resultNumber1 = 0;
		Imformation1 memberImformation2 = new Imformation1(loginid.getText(), loginpw.getText());
		Imformation memberImformation1 = new Imformation(loginid.getText(), loginpw.getText());
		resultNumber2 = mDAO.loginValue(memberImformation2);
		resultNumber1 = lDAO.loginValue(memberImformation1);
		
		if(resultNumber2 == 1) {
			Stage stage = new Stage();
			stage.initOwner(primaryStage);
			stage.initModality(Modality.WINDOW_MODAL);
			stage.setTitle("관리자 모드");
			Parent root = null;
		
		if( mDAO.check == true ) {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/mastermenu.fxml"));
			try {
				root = fxmlLoader.load();		
			} catch (Exception e1) {	}
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
			fun.alertDisplay(2, "로그인", "로그인 성공", "관리자님 환영합니다");
			
			ImageView customerlist = (ImageView)root.lookup("#customerlist");
			customerlist.setOnMouseClicked((e1) ->{
				customerlistStart(e1);
			});
			
			ImageView trainlist = (ImageView)root.lookup("#trainlist");
			trainlist.setOnMouseClicked((e1) ->{
				trainlistStart(e1);
			});
			
		}else if(mDAO.check == false){
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/trainermenu.fxml"));
			stage.setTitle("트레이너모드");
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e1) {	}
			Scene scene = new Scene(root);
			stage.setScene(scene);
			
			stage.show();
			fun.alertDisplay(2, "로그인", "로그인 성공", "헬스장 트레이너님 환영합니다.");
			
			ImageView TrainerInCustomerList = (ImageView)root.lookup("#TrainerInCustomerList");
			TrainerInCustomerList.setOnMouseClicked((e1) ->{
				TrainerInCustomerListStart(e1);
			});
		}
		}
		else if(resultNumber1 == 1) {
			Stage stage = new Stage();
			stage.initOwner(primaryStage);
			stage.initModality(Modality.WINDOW_MODAL);
			stage.setTitle("고객모드");
			Parent root = null;
		
		if ( mDAO.check == false != lDAO.admincheck == true){
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/customermenu.fxml"));
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e1) {	}
			Scene scene = new Scene(root);
			stage.setScene(scene);
			
			stage.show();
			fun.alertDisplay(2, "로그인", "로그인 성공", "헬스장 이용고객님 입니다");
			
			Button Shouldermovement = (Button)root.lookup("#Shouldermovement");
			Shouldermovement.setOnAction((e1) ->{ //어깨 운동 설명버튼
				ShouldermovementStart(e1);
			});
			
			Button Chestexercise = (Button)root.lookup("#Chestexercise");
			Chestexercise.setOnAction((e1) ->{ // 가슴운동 설명버튼
				ChestexerciseStart(e1);
			});
			
			Button Backexercise = (Button)root.lookup("#Backexercise");
			Backexercise.setOnAction((e1) ->{ //등 운동 설명버튼
				BackexerciseStart(e1);
			});
			
			Button Legexercise = (Button)root.lookup("#Legexercise");
			Legexercise.setOnAction((e1) ->{ // 다리 운동 설명버튼
				LegexerciseStart(e1);
			});
			
			Button Idiopathicexercise = (Button)root.lookup("#Idiopathicexercise");
			Idiopathicexercise.setOnAction((e1) ->{ //이두 운동 설명 버튼
				IdiopathicexerciseStart(e1);
			});
			
			Button Tripletexercise = (Button)root.lookup("#Tripletexercise");
			Tripletexercise.setOnAction((e1) ->{ //삼두 운동 설명 버튼
				TripletexerciseStart(e1);
			});
		}
		}else {
			fun.alertDisplay(1, "로그인", "로그인 실패", "아이디 또는 비밀번호를 다시입력하세요");
		}
}
	
	private void handlercustomerSignup(ActionEvent e) {
		idOverlap = true;
		Stage stage = new Stage();
		stage.initOwner(primaryStage);
		stage.initModality(Modality.WINDOW_MODAL);
		stage.setTitle("회원가입정보");

		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/customersignup.fxml"));
		Parent root = null;
		try {
			root = fxmlLoader.load();

		} catch (Exception e1) {
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		TextField Name = (TextField) root.lookup("#name");
		TextField Height = (TextField) root.lookup("#Height");
		TextField Weight = (TextField) root.lookup("#Weight");
		TextField Career = (TextField) root.lookup("#Career");
		TextField Txtid = (TextField) root.lookup("#txtid");
		TextField tel1 = (TextField) root.lookup("#tel1");
		TextField tel2 = (TextField) root.lookup("#tel2");
		TextField tel3 = (TextField) root.lookup("#tel3");
		PasswordField TxtPW = (PasswordField) root.lookup("#txtpw");
		TextField jumin1 = (TextField) root.lookup("#jumin1");
		PasswordField jumin2 = (PasswordField) root.lookup("#jumin2");
		Button btnOk = (Button) root.lookup("#btnOk");
		Button btnCan = (Button) root.lookup("#btnCan");
		Button btnCheck = (Button) root.lookup("#btnCheck");


		Name.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[가-힣]*$";// 한글만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 6) { // 이름은 5글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Txtid.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[a-zA-Z0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 11) { // 아이디는 10글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		TxtPW.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?~`]*$";// 영어 , 숫자, 특수문자만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 11) {// 비밀번호는 10글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		jumin1.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 7) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		jumin2.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 8) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));


		tel1.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 전화번호는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		tel2.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 5) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		tel3.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 5) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		Height.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 키는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Weight.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 몸무게는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Career.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}

			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 3) { // 경력은 2글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		btnCheck.setOnAction((e1) -> {
			Connection con = null;
			int overlapCount = 0;
			try {
				con = DBfile.getConnection();
			} catch (Exception e2) {
			}

			PreparedStatement pstmt = null;
			String dml = "select c_id from customer";
			String dlm = "select t_id from trainer";
			try {
				pstmt = con.prepareStatement(dml);
				pstmt = con.prepareStatement(dlm);
				ResultSet queryResult = pstmt.executeQuery();

				while (queryResult.next()) {
					String id = String.valueOf(queryResult.getString(1));

					if (id.equals(Txtid.getText()) || Txtid.getText().equals("")) {
						overlapCount++;
					}
				}

				if (overlapCount == 0) {
					idOverlap = false;
					fun.alertDisplay(1, "중복검사", "중복없음", "환영합니다");
				} else {
					idOverlap = true;
					fun.alertDisplay(2, "중복검사", "아이디중복 또는 미입력", "다시입력해주세요");
				}

			} catch (SQLException e2) {
			}

		});
		
		btnOk.setOnAction((e2) -> {
			String Jumin = jumin1.getText() +"-"+ jumin2.getText();
			String Tel = tel1.getText() + "-" + tel2.getText() + "-" + tel3.getText(); 
			
			if(idOverlap == false && passwordOverlap == false) {
		        Imformation memberImformation = new Imformation( null,Name.getText(), Jumin, Tel, Height.getText(), Weight.getText(), null,  null, Txtid.getText(), TxtPW.getText(), Career.getText());
		        /*MoneyMethod mm = new MoneyMethod(loginID.getText(), 0, 0, null, null, strLocalDate, "회원가입 축하드립니다");*/
		 
		        
				int resultNumber = lDAO.Insertmemberimpormation(memberImformation);
				if (resultNumber == 0) {
					fun.alertDisplay(1, "회원가입", "실패", "빠진부분이 있는지 확인하세요");
				} else {
					fun.alertDisplay(2, "회원가입", "성공", "어서오세요");
					stage.close();
				}	
			}else {
				fun.alertDisplay(1, "로그인실패", "아이디 및 패스워드 오류", "확인해주세요");
			}
		});
		
		btnCan.setOnAction((e2) -> {
			stage.close();
		});
	}
	
	private void handlertrainSignup(ActionEvent e) {
		idOverlap = true;
		Stage stage = new Stage();
		stage.initOwner(primaryStage);
		stage.initModality(Modality.WINDOW_MODAL);
		stage.setTitle("회원가입정보");

		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/mastersignup.fxml"));
		Parent root = null;
		try {
			root = fxmlLoader.load();

		} catch (Exception e1) {
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		TextField Name = (TextField) root.lookup("#trainname");
		TextField Height = (TextField) root.lookup("#Height");
		TextField Weight = (TextField) root.lookup("#Weight");
		TextField Career = (TextField) root.lookup("#Career");
		TextField Txtid = (TextField) root.lookup("#txtid");
		TextField tel1 = (TextField) root.lookup("#tel1");
		TextField tel2 = (TextField) root.lookup("#tel2");
		TextField tel3 = (TextField) root.lookup("#tel3");
		PasswordField TxtPW = (PasswordField) root.lookup("#txtpw");
		TextField jumin1 = (TextField) root.lookup("#jumin1");
		PasswordField jumin2 = (PasswordField) root.lookup("#jumin2");
		Button btnOk = (Button) root.lookup("#btnOk");
		Button btnCan = (Button) root.lookup("#btnCan");
		Button btnCheck = (Button) root.lookup("#btnCheck");

		Name.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[가-힣]*$";// 한글만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 6) { // 이름은 5글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Txtid.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[a-zA-Z0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 11) { // 아이디는 10글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		TxtPW.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?~`]*$";// 영어 , 숫자, 특수문자만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 11) {// 비밀번호는 10글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		jumin1.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 7) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		jumin2.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 8) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));


		tel1.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 전화번호는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		tel2.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 5) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		tel3.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 5) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		Height.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 키는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Weight.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 몸무게는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Career.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}

			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 3) { // 경력은 2글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		btnCheck.setOnAction((e1) -> {
			Connection con = null;
			int overlapCount = 0;
			try {
				con = DBfile.getConnection();
			} catch (Exception e2) {
			}

			PreparedStatement pstmt = null;
			String dml = "select t_id from trainer";
			String dlm = "select c_id from customer";
			try {
				pstmt = con.prepareStatement(dml);
				pstmt = con.prepareStatement(dlm);
				ResultSet queryResult = pstmt.executeQuery();

				while (queryResult.next()) {
					String id = String.valueOf(queryResult.getString(1));

					if (id.equals(Txtid.getText()) || Txtid.getText().equals("")) {
						overlapCount++;
					}
				}

				if (overlapCount == 0) {
					idOverlap = false;
					fun.alertDisplay(1, "중복검사", "중복없음", "환영합니다");
				} else {
					idOverlap = true;
					fun.alertDisplay(2, "중복검사", "아이디중복 또는 미입력", "다시입력해주세요");
				}

			} catch (SQLException e2) {
			}

		});
		
		btnOk.setOnAction((e2) -> {
			String Jumin = jumin1.getText() +"-"+ jumin2.getText();
			String Tel = tel1.getText() + "-" + tel2.getText() + "-" + tel3.getText(); 
			if(idOverlap == false && passwordOverlap == false) {
		        Imformation1 memberImformation = new Imformation1(null,Name.getText(), Jumin,Height.getText(), Weight.getText(), Career.getText(), null, Tel, null,Txtid.getText(), TxtPW.getText());
		        /*MoneyMethod mm = new MoneyMethod(loginID.getText(), 0, 0, null, null, strLocalDate, "회원가입 축하드립니다");*/
		        
		       
		        
				int resultNumber = mDAO.Insertmemberimpormation(memberImformation);
				if (resultNumber == 0) {
					fun.alertDisplay(1, "회원가입", "실패", "빠진부분이 있는지 확인하세요");
				} else {
					fun.alertDisplay(2, "회원가입", "성공", "어서오세요");
					stage.close();
				}	
			}else {
				fun.alertDisplay(1, "로그인실패", "아이디 및 패스워드 오류", "확인해주세요");
			}
		});
		
		btnCan.setOnAction((e2) -> {
			stage.close();
		});
	}
	
	//관리자모드에서 고객정보 확인
		private void customerlistStart(MouseEvent e1) {
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("회원정보관리");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/masterincustomerlist.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			customerlistController adc = fxmlLoader.getController();
			adc.setlistController(primaryStage);
			adc.setNowLoginId(loginid.getText());
			Button btnclose = (Button)root.lookup("#btnclose");
			
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
			btnclose.setOnAction((e2) -> {
				stage2.close();
			});
		}
	// 관리자모드에서 트레이너 정보 확인
		private void trainlistStart(MouseEvent e1) {
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("회원정보관리");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/MasterInTrainerList.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			trainerlistController adc = fxmlLoader.getController();
			adc.setlistController(primaryStage);
			adc.setNowLoginId(loginid.getText());
			Button btnclose = (Button)root.lookup("#btnclose");
			
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
			btnclose.setOnAction((e2) -> {
				stage2.close();
			});
		}
		
	//트레이너 메뉴에 잇는 고객정보버튼을 눌러 고객정보 확인
		private void TrainerInCustomerListStart(MouseEvent e1) {
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("회원정보관리");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/TrainerInCustomerList.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			TrainerinListController adc = fxmlLoader.getController();
			adc.setlistController(primaryStage);
			adc.setNowLoginId(loginid.getText());
			Button btnclose = (Button)root.lookup("#btnclose");
			
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
			btnclose.setOnAction((e2) -> {
				stage2.close();
			});
		}
		
		private void ShouldermovementStart(ActionEvent e1) { //어깨운동 설명버튼
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("어깨 운동설명");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/FitnessEquipmentView/Shouldermovement.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
		}
		
		private void ChestexerciseStart(ActionEvent e1) { // 가슴운동 설명버튼
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("가슴 운동설명");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/FitnessEquipmentView/Chestexercise.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
		}
		
		private void BackexerciseStart(ActionEvent e1) { // 등운동 설명버튼
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("등 운동설명");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/FitnessEquipmentView/Backexercise.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
		}
		
		private void LegexerciseStart(ActionEvent e1) { // 다리운동 설명버튼
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("다리 운동설명");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/FitnessEquipmentView/Legexercise.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
		}
		
		private void IdiopathicexerciseStart(ActionEvent e1) { // 이두운동 설명버튼
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("이두 운동설명");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/FitnessEquipmentView/Idiopathicexercise.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
		}
		
		private void TripletexerciseStart(ActionEvent e1) { // 삼두운동 설명버튼
			Stage stage2 = new Stage();
			stage2.initOwner(primaryStage);
			stage2.initModality(Modality.WINDOW_MODAL);
			stage2.setTitle("삼두 운동설명");

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/FitnessEquipmentView/Tripletexercise.fxml"));
			Parent root = null;
			try {
				root = fxmlLoader.load();
						
			} catch (Exception e2) {	}
			Scene scene = new Scene(root);
			stage2.setScene(scene);
			stage2.show();
		}
	
	public void handlebtnClose(ActionEvent e) {
		Platform.exit();
	}
}