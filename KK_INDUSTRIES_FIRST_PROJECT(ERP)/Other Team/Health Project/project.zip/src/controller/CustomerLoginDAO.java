package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import controller.DBfile;
import model.Imformation;
//import model.MoneyMethod;



public class CustomerLoginDAO {
	boolean admincheck;
	
	
	public int editImformation(Imformation memberImformation, String userID) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int queryResultNumber = 0;
		
		try {
			con = DBfile.getConnection();
			String dml = "update customer set c_name = ? , c_id = ?, c_pw = ?, c_jumin = ?, c_tel = ?, c_Height = ?, c_Weight = ?, c_Career = ? where c_id = ?";
			pstmt = con.prepareStatement(dml);
			
			pstmt.setString(1, memberImformation.getName());
			pstmt.setString(2, memberImformation.getTxtid());
			pstmt.setString(3, memberImformation.getTxtPW());
			pstmt.setString(4, memberImformation.getJumin());
			pstmt.setString(5, memberImformation.getTel());
			pstmt.setString(6, memberImformation.getHeight());
			pstmt.setString(7, memberImformation.getWeight());
			pstmt.setString(8, memberImformation.getCareer());
			pstmt.setString(9,  userID);
			
			queryResultNumber = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println("error = [" + e + "]");
		} catch (Exception e1) {
			System.out.println("error = [" + e1 + "]");
		} finally {
			
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				
				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			}
		} // end to finally
		return queryResultNumber;
	}
	
	public Imformation loadMemberEdit(String userID) {
		Imformation memberImformation1 = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		int queryResultNumber = 0;
		
		try {
			con = DBfile.getConnection();
			String dml = "select c_name, c_id, c_pw, c_jumin, c_tel, c_Height, c_Weight, c_Career from customer where c_id = ?";
					
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, userID);
			
			ResultSet queryResultSet = pstmt.executeQuery();
			
			while(queryResultSet.next()) {
				String custno = String.valueOf(queryResultSet.getString(1));
				String Name  = String.valueOf(queryResultSet.getString(2));
				String Jumin = String.valueOf(queryResultSet.getString(3));
				String Tel = String.valueOf(queryResultSet.getString(4));
				String Height = String.valueOf(queryResultSet.getString(5));
				String Weight= String.valueOf(queryResultSet.getString(6));
				String Gender = String.valueOf(queryResultSet.getString(7));
				String Pay = String.valueOf(queryResultSet.getString(8));
				String txtid = String.valueOf(queryResultSet.getString(9));
				String txtPW = String.valueOf(queryResultSet.getString(10));
				String Career = String.valueOf(queryResultSet.getString(11));
				memberImformation1 = new Imformation(custno, Name, Jumin, Tel, Height, Weight, Gender, Pay, txtid, txtPW, Career);

			}
			
			
		} catch (SQLException e) {
			System.out.println("error = [" + e + "]");
		} catch (Exception e1) {
			System.out.println("error = [" + e1 + "]");
		} finally {

			try {
				if (pstmt != null) {
					pstmt.close();
				}

				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			}
		} // end to finally
		
		return memberImformation1;
	}
	
	public int loginValue(Imformation memberImformation){
		admincheck = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		int queryResultNumber = 0;
		
		try {
			con = DBfile.getConnection();
			String dml = "select c_id, c_pw from customer where c_id = ?";
					
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, memberImformation.getTxtid());
			
			ResultSet queryResultSet = pstmt.executeQuery();
			
			while(queryResultSet.next()) {
				String id = String.valueOf(queryResultSet.getString(1));
				String password = String.valueOf(queryResultSet.getString(2));
				
				if(id.equals(memberImformation.getTxtid()) && password.equals(memberImformation.getTxtPW())) {
					if(id.equals(" ") && password.equals(" ")) {
						admincheck = true; // 관리자임을 알리기 위해 사용
					}
					queryResultNumber ++;
				}
			}
			
			
		} catch (SQLException e) {
			System.out.println("error = [" + e + "]");
		} catch (Exception e1) {
			System.out.println("error = [" + e1 + "]");
		} finally {

			try {
				if (pstmt != null) {
					pstmt.close();
				}

				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			}
		} // end to finally
		return queryResultNumber;
	}
	
	
	public int Insertmemberimpormation(Imformation memberImformation) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int queryResultNumber = 0;
		
		try {
			con = DBfile.getConnection();
			String dml = "insert into customer "
					+ "(custno, c_name, c_id, c_pw, c_jumin, c_tel, c_height, c_weight, c_career )"
					+ " values " + "(customer_custno_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(dml);
			
			pstmt.setString(1, memberImformation.getName());
			pstmt.setString(2, memberImformation.getTxtid());
			pstmt.setString(3, memberImformation.getTxtPW());
			pstmt.setString(4, memberImformation.getJumin());
			pstmt.setString(5, memberImformation.getTel());
			pstmt.setString(6, memberImformation.getHeight());
			pstmt.setString(7, memberImformation.getWeight());
			pstmt.setString(8, memberImformation.getCareer());
			
			queryResultNumber = pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			System.out.println("error = [" + e + "]");
		} catch (Exception e1) {
			System.out.println("error = [" + e1 + "]");
		} finally {

			try {
				if (pstmt != null) {
					pstmt.close();
				}

				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			}
		} // end to finally
		return queryResultNumber;
	}
	
	public void deleteUse(String loginID) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int queryResultNumber = 0;

		try {
			con = DBfile.getConnection();
			String dml = "delete from customer where c_id = ?";
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, loginID);

			
			queryResultNumber = pstmt.executeUpdate(); 

		} catch (SQLException e) {
			System.out.println("error = [" + e + "]");
		} catch (Exception e1) {
			System.out.println("error = [" + e1 + "]");
		} finally {

			try {
				if (pstmt != null) {
					pstmt.close();
				}

				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				System.out.println("error = [" + e1 + "]");
			}
		}
		return;
	}
}
