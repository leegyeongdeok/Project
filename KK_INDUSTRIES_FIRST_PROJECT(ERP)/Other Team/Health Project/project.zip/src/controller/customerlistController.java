package controller;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import controller.listDAO;
import controller.function;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Imformation;

public class customerlistController implements Initializable{
	@FXML
	private Button btnnamelist; // 검색버튼
	@FXML
	private Button btnAll; // 전체조회버튼
	@FXML
	private TextField nameTable; // 입력창
	@FXML
	private TableView<Imformation> customerlistView; //출력화면
	@FXML 
	private String nowLoginId;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnEdit;
	
	private Imformation imformation;
	private int tableSelectIndex;
	private function fun = new function();
	private listDAO lDAO = new listDAO();

	
	public void setNowLoginId(String nowLoginId) {
		this.nowLoginId = nowLoginId;
	}
	
	public String getNowLoginId() {
		return nowLoginId;
	}
	
	private Stage listController;
	ObservableList<Imformation> data;
	
	public void setlistController(Stage listController) {
		this.listController = listController;
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tableViewSetColData();
		btnAll.setOnAction((e) ->{handlerInquiry(e);}) ;//전체 조회 
		btnnamelist.setOnAction((e) -> {handlerNameInQuiry(e);}); // 이름 검색 조회
		customerlistView.setOnMousePressed((e) ->{handlerTableViewSelected(e);});
		btnDelete.setOnAction((e) -> {handlerMemberDelete(e);});
		btnEdit.setOnAction((e) -> {handlerMemberEdit(e);});
	}
	private void handlerMemberDelete(ActionEvent e) {
		lDAO.deleteUse(imformation.getTxtid());
		fun.alertDisplay(2, "탈퇴", "회원탈퇴", "탈퇴처리 되었습니다");
		
		 ArrayList<Imformation> list = lDAO.memberAllLoad();
		 if(list == null) {
			 fun.alertDisplay(1, "불러오기", "실패", "불러오기 오류입니다");	 
		 }else {
			 data.removeAll(data);
			 for(Imformation memberImformation : list) {
				 data.add(memberImformation);
			 }
		 }
	}
	
	private void handlerInquiry(ActionEvent e) {
		 ArrayList<Imformation> list = lDAO.memberAllLoad();
		 if(list == null) {
			 fun.alertDisplay(1, "불러오기", "실패", "불러오기 오류입니다");	 
		 }else {
			 data.removeAll(data);
			 for(Imformation memberImformation : list) {
				 data.add(memberImformation);
			 }
		 }
		
	}
	
	private void handlerNameInQuiry(ActionEvent e) {
		ArrayList<Imformation> list = lDAO.memberNameLoad(nameTable.getText());
		 if(list == null) {
			 fun.alertDisplay(1, "불러오기", "실패", "불러오기 오류입니다");	 
		 }else {
			 data.removeAll(data);
			 for(Imformation memberImformation : list) {
				 data.add(memberImformation);
			 }
		 }
		 nameTable.clear();
	}
	
	private void handlerTableViewSelected(MouseEvent e) {
		customerlistView.getSelectionModel().getSelectedItem();
		imformation = customerlistView.getSelectionModel().getSelectedItem();
		tableSelectIndex = customerlistView.getSelectionModel().getSelectedIndex();
	}
	
private void handlerMemberEdit(ActionEvent e) {
		
		Stage stage = new Stage();
		stage.initOwner(listController);
		stage.initModality(Modality.WINDOW_MODAL);
		stage.setTitle("회원정보 수정");
		Parent root = null;

		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/ImformationEdit.fxml"));
		try {
			root = fxmlLoader.load();
		} catch (Exception e1) {
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		TextField Name = (TextField) root.lookup("#name");
		TextField Height = (TextField) root.lookup("#Height");
		TextField Weight = (TextField) root.lookup("#Weight");
		TextField Career = (TextField) root.lookup("#Career");
		TextField Txtid = (TextField) root.lookup("#txtid");
		TextField tel1 = (TextField) root.lookup("#tel1");
		TextField tel2 = (TextField) root.lookup("#tel2");
		TextField tel3 = (TextField) root.lookup("#tel3");
		PasswordField TxtPW = (PasswordField) root.lookup("#txtpw");
		TextField jumin1 = (TextField) root.lookup("#jumin1");
		PasswordField jumin2 = (PasswordField) root.lookup("#jumin2");
		Button btnOk = (Button) root.lookup("#btnOk");
		Button btnCan = (Button) root.lookup("#btnCan");
		
		Name.setText(imformation.getName());
        Height.setText(imformation.getHeight());
        Weight.setText(imformation.getWeight());
        Career.setText(imformation.getCareer());
        Txtid.setText(imformation.getTxtid());
        Txtid.setEditable(false);
        TxtPW.setText(imformation.getTxtPW());

		Name.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[가-힣]*$";// 한글만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 6) { // 이름은 5글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Txtid.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[a-zA-Z0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 11) { // 아이디는 10글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		TxtPW.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?~`]*$";// 영어 , 숫자, 특수문자만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 11) {// 비밀번호는 10글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		jumin1.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 7) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		jumin2.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 8) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));


		tel1.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 전화번호는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		tel2.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 5) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		tel3.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 5) { // 주민번호는 6글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		Height.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 키는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Weight.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 4) { // 몸무게는 3글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));

		Career.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}

			String pattern = "^[0-9]*$";// 영어, 숫자 만 받습니다
			boolean i = Pattern.matches(pattern, event.getControlNewText());
			if (!i || event.getControlNewText().length() == 3) { // 경력은 2글자까지 입력가능합니다.
				// 조건문엔 받아올 텍스트의 판별 결과(Boolean)와 텍스트길이를 설정해줍니다.
				return null;
			} else {
				return event;
			}
		}));
		
		btnOk.setOnAction((e1) ->{
			String Jumin = jumin1.getText() +"-"+ jumin2.getText();
			String Tel = tel1.getText() + "-" + tel2.getText() + "-" + tel3.getText(); 
        	Imformation memberImformation = new Imformation(null,Name.getText(), Jumin, Tel, Height.getText(), Weight.getText(), null,  null, Txtid.getText(), TxtPW.getText(), Career.getText());
        		int resultNumber = lDAO.editImformation(memberImformation, imformation);
        		ArrayList<Imformation> list = lDAO.editImformationView(memberImformation, imformation);
        		data.remove(tableSelectIndex);
        		for(Imformation memberImformation3 : list) {
        			data.add(tableSelectIndex, memberImformation3);
        		}
        		stage.close();
        	}
        );
		btnCan.setOnAction((e1) -> {stage.close();});
}
	private void tableViewSetColData() {
	      data = FXCollections.observableArrayList();
	      customerlistView.setEditable(true);        

	      
	      TableColumn colno = new TableColumn("등록번호");  
	      colno.setMinWidth(50);      
	      colno.setStyle("-fx-alignment: CENTER");      
	      colno.setCellValueFactory(new PropertyValueFactory<>("custno"));   
	      
	      TableColumn colName = new TableColumn("이름");
	      colName.setMinWidth(100);    
	      colName.setStyle("-fx-alignment: CENTER");     
	      colName.setCellValueFactory(new PropertyValueFactory<>("Name"));
	      
	      TableColumn colJumin= new TableColumn("주민번호");
	      colJumin.setMinWidth(150);    
	      colJumin.setStyle("-fx-alignment: CENTER");    
	      colJumin.setCellValueFactory(new PropertyValueFactory<>("Jumin"));
	      
	      TableColumn colTel = new TableColumn("전화번호");
	      colTel.setMinWidth(150);     
	      colTel.setStyle("-fx-alignment: CENTER");      
	      colTel.setCellValueFactory(new PropertyValueFactory<>("Tel"));
	      
	      TableColumn colHeight = new TableColumn("키");
	      colHeight.setMinWidth(100);      
	      colHeight.setStyle("-fx-alignment: CENTER");      
	      colHeight.setCellValueFactory(new PropertyValueFactory<>("Height"));
	      
	      TableColumn colWeight = new TableColumn("몸무게");
	      colWeight.setMinWidth(100);      
	      colWeight.setStyle("-fx-alignment: CENTER");      
	      colWeight.setCellValueFactory(new PropertyValueFactory<>("Weight"));
	      
	      TableColumn colGender = new TableColumn("성별");
	      colGender.setMinWidth(100);      
	      colGender.setStyle("-fx-alignment: CENTER");      
	      colGender.setCellValueFactory(new PropertyValueFactory<>("C_GENDER"));
	      
	      TableColumn colPay = new TableColumn("결제");
	      colPay.setMinWidth(100);      
	      colPay.setStyle("-fx-alignment: CENTER");      
	      colPay.setCellValueFactory(new PropertyValueFactory<>("C_PAY"));
	      
	      TableColumn colID = new TableColumn("아이디");
	      colID.setMinWidth(100);      
	      colID.setStyle("-fx-alignment: CENTER");      
	      colID.setCellValueFactory(new PropertyValueFactory<>("txtid"));
	      
	      TableColumn colPW = new TableColumn("비밀번호");
	      colPW.setMinWidth(100);      
	      colPW.setStyle("-fx-alignment: CENTER");      
	      colPW.setCellValueFactory(new PropertyValueFactory<>("txtPW"));
	      
	      TableColumn colCareer = new TableColumn("경력");
	      colCareer.setMinWidth(100);      
	      colCareer.setStyle("-fx-alignment: CENTER");      
	      colCareer.setCellValueFactory(new PropertyValueFactory<>("Career"));

	      
	      customerlistView.setItems(data);
	      customerlistView.getColumns().add(colno);
	      customerlistView.getColumns().add(colName);
	      customerlistView.getColumns().add(colJumin);
	      customerlistView.getColumns().add(colTel);
	      customerlistView.getColumns().add(colHeight);
	      customerlistView.getColumns().add(colWeight);
	      customerlistView.getColumns().add(colGender);
	      customerlistView.getColumns().add(colPay);
	      customerlistView.getColumns().add(colID);
	      customerlistView.getColumns().add(colPW);
	      customerlistView.getColumns().add(colCareer);
	
}
}