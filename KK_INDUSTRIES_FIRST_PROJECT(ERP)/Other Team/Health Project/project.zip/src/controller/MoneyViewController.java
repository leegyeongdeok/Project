package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import javafx.stage.Stage;

public class MoneyViewController implements Initializable{
	private Stage listController;
	private String nowLoginId;
	public void setlistController(Stage listController) {
		this.listController = listController;
	}
	public void setNowLoginId(String nowLoginId) {
		this.nowLoginId = nowLoginId;
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}

	
}