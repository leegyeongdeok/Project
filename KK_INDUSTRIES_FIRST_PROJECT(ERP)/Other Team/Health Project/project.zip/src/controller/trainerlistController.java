package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import controller.TrainerListDAO;
import controller.function;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Imformation;
import model.Imformation1;

public class trainerlistController implements Initializable{
	@FXML
	private Button btnnamelist; // 검색버튼
	@FXML
	private Button btnAll; // 전체조회버튼
	@FXML
	private TextField nameTable; // 입력창
	@FXML
	private TableView<Imformation1> trainerlistView; //출력화면	
	@FXML
	private Button btnDelete;
	
	private String nowLoginId;
	private Imformation1 imformation1;
	private function fun = new function();
	private TrainerListDAO tDAO = new TrainerListDAO();

	
	public void setNowLoginId(String nowLoginId) {
		this.nowLoginId = nowLoginId;
	}
	
	public String getNowLoginId() {
		return nowLoginId;
	}
	
	private Stage listController;
	ObservableList<Imformation1> data;
	
	public void setlistController(Stage listController) {
		this.listController = listController;
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tableViewSetColData();
		btnAll.setOnAction((e) ->{handlerInquiry(e);}) ;//전체 조회 
		btnnamelist.setOnAction((e) -> {handlerNameInQuiry(e);}); // 이름 검색 조회
		trainerlistView.setOnMousePressed((e) ->{handlerTableViewSelected(e);});
		btnDelete.setOnAction((e) -> {handlerMemberDelete(e);});
	}
	
	private void handlerMemberDelete(ActionEvent e) {
		tDAO.deleteUse(imformation1.getTxtid());
		fun.alertDisplay(2, "탈퇴", "회원탈퇴", "탈퇴처리 되었습니다");
		
		 ArrayList<Imformation1> list = tDAO.memberAllLoad();
		 if(list == null) {
			 fun.alertDisplay(1, "불러오기", "실패", "불러오기 오류입니다");	 
		 }else {
			 data.removeAll(data);
			 for(Imformation1 memberImformation : list) {
				 data.add(memberImformation);
			 }
		 }
	}
	
	
	private void handlerInquiry(ActionEvent e) {
		 ArrayList<Imformation1> list = tDAO.memberAllLoad();
		 if(list == null) {
			 fun.alertDisplay(1, "불러오기", "실패", "불러오기 오류입니다");	 
		 }else {
			 data.removeAll(data);
			 for(Imformation1 memberImformation : list) {
				 data.add(memberImformation);
			 }
		 }
		
	}
	
	private void handlerNameInQuiry(ActionEvent e) {
		ArrayList<Imformation1> list = tDAO.memberNameLoad(nameTable.getText());
		 if(list == null) {
			 fun.alertDisplay(1, "불러오기", "실패", "불러오기 오류입니다");	 
		 }else {
			 data.removeAll(data);
			 for(Imformation1 memberImformation : list) {
				 data.add(memberImformation);
			 }
		 }
		 nameTable.clear();
	}
	
	private void handlerTableViewSelected(MouseEvent e) {
		trainerlistView.getSelectionModel().getSelectedItem();
		imformation1 = trainerlistView.getSelectionModel().getSelectedItem();
	}
	
	private void tableViewSetColData() {
	      data = FXCollections.observableArrayList();
	      trainerlistView.setEditable(true);        

	      
	      TableColumn colno = new TableColumn("등록번호");  
	      colno.setMinWidth(50);      
	      colno.setStyle("-fx-alignment: CENTER");      
	      colno.setCellValueFactory(new PropertyValueFactory<>("trainno"));   
	      
	      TableColumn colName = new TableColumn("이름");
	      colName.setMinWidth(100);    
	      colName.setStyle("-fx-alignment: CENTER");     
	      colName.setCellValueFactory(new PropertyValueFactory<>("Name"));
	      
	      TableColumn colJumin= new TableColumn("주민번호");
	      colJumin.setMinWidth(150);    
	      colJumin.setStyle("-fx-alignment: CENTER");    
	      colJumin.setCellValueFactory(new PropertyValueFactory<>("Jumin"));
	      
	      TableColumn colHeight = new TableColumn("키");
	      colHeight.setMinWidth(100);      
	      colHeight.setStyle("-fx-alignment: CENTER");      
	      colHeight.setCellValueFactory(new PropertyValueFactory<>("Height"));
	      
	      TableColumn colWeight = new TableColumn("몸무게");
	      colWeight.setMinWidth(100);      
	      colWeight.setStyle("-fx-alignment: CENTER");      
	      colWeight.setCellValueFactory(new PropertyValueFactory<>("Weight"));
	      
	      TableColumn colCareer = new TableColumn("경력");
	      colCareer.setMinWidth(100);      
	      colCareer.setStyle("-fx-alignment: CENTER");      
	      colCareer.setCellValueFactory(new PropertyValueFactory<>("Career"));

	      TableColumn colGender = new TableColumn("성별");
	      colGender.setMinWidth(100);      
	      colGender.setStyle("-fx-alignment: CENTER");      
	      colGender.setCellValueFactory(new PropertyValueFactory<>("T_GENDER"));
	     
	      TableColumn colTel = new TableColumn("전화번호");
	      colTel.setMinWidth(150);     
	      colTel.setStyle("-fx-alignment: CENTER");      
	      colTel.setCellValueFactory(new PropertyValueFactory<>("Tel"));
	      
	      
	      TableColumn colPay = new TableColumn("결제");
	      colPay.setMinWidth(100);      
	      colPay.setStyle("-fx-alignment: CENTER");      
	      colPay.setCellValueFactory(new PropertyValueFactory<>("T_PAY"));
	      
	      TableColumn colID = new TableColumn("아이디");
	      colID.setMinWidth(100);      
	      colID.setStyle("-fx-alignment: CENTER");      
	      colID.setCellValueFactory(new PropertyValueFactory<>("txtid"));
	      
	      TableColumn colPW = new TableColumn("비밀번호");
	      colPW.setMinWidth(100);      
	      colPW.setStyle("-fx-alignment: CENTER");      
	      colPW.setCellValueFactory(new PropertyValueFactory<>("txtPW"));
	      

	      
	      trainerlistView.setItems(data);
	      trainerlistView.getColumns().add(colno);
	      trainerlistView.getColumns().add(colName);
	      trainerlistView.getColumns().add(colJumin);
	      trainerlistView.getColumns().add(colHeight);
	      trainerlistView.getColumns().add(colWeight);
	      trainerlistView.getColumns().add(colCareer);
	      trainerlistView.getColumns().add(colGender);
	      trainerlistView.getColumns().add(colTel);
	      trainerlistView.getColumns().add(colPay);
	      trainerlistView.getColumns().add(colID);
	      trainerlistView.getColumns().add(colPW);
	
}
}